import { Component } from '@angular/core';

@Component({
  selector: 'app-manager-order',
  imports: [],
  templateUrl: './manager-order.component.html',
  styleUrl: './manager-order.component.css'
})
export class ManagerOrderComponent {

}
