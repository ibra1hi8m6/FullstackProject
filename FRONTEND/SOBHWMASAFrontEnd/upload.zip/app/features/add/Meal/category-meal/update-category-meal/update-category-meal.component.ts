import { Component } from '@angular/core';

@Component({
  selector: 'app-update-category-meal',
  imports: [],
  templateUrl: './update-category-meal.component.html',
  styleUrl: './update-category-meal.component.css'
})
export class UpdateCategoryMealComponent {

}
