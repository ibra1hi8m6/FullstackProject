import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-category-meal',
  imports: [RouterModule],
  templateUrl: './category-meal.component.html',
  styleUrl: './category-meal.component.css'
})
export class CategoryMealComponent {

}
