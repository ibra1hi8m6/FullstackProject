import { Component } from '@angular/core';

@Component({
  selector: 'app-delete-category-meal',
  imports: [],
  templateUrl: './delete-category-meal.component.html',
  styleUrl: './delete-category-meal.component.css'
})
export class DeleteCategoryMealComponent {

}
