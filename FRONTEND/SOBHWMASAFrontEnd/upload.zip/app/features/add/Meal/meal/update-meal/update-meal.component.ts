import { Component } from '@angular/core';

@Component({
  selector: 'app-update-meal',
  imports: [],
  templateUrl: './update-meal.component.html',
  styleUrl: './update-meal.component.css'
})
export class UpdateMealComponent {

}
