import { Component } from '@angular/core';

@Component({
  selector: 'app-delete-meal',
  imports: [],
  templateUrl: './delete-meal.component.html',
  styleUrl: './delete-meal.component.css'
})
export class DeleteMealComponent {

}
