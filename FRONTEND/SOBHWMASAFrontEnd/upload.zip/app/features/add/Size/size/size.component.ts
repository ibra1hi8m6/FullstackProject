import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-size',
  standalone:true,
  imports: [RouterModule],
  templateUrl: './size.component.html',
  styleUrl: './size.component.css'
})
export class SizeComponent {

}
