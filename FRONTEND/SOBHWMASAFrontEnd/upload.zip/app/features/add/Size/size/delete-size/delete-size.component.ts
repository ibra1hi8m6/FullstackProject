import { Component } from '@angular/core';

@Component({
  selector: 'app-delete-size',
  imports: [],
  templateUrl: './delete-size.component.html',
  styleUrl: './delete-size.component.css'
})
export class DeleteSizeComponent {

}
