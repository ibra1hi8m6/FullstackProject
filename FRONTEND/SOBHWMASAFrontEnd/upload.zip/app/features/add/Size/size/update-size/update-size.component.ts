import { Component } from '@angular/core';

@Component({
  selector: 'app-update-size',
  imports: [],
  templateUrl: './update-size.component.html',
  styleUrl: './update-size.component.css'
})
export class UpdateSizeComponent {

}
