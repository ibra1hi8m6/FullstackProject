import { Component } from '@angular/core';

@Component({
  selector: 'app-delete-category-size',
  imports: [],
  templateUrl: './delete-category-size.component.html',
  styleUrl: './delete-category-size.component.css'
})
export class DeleteCategorySizeComponent {

}
