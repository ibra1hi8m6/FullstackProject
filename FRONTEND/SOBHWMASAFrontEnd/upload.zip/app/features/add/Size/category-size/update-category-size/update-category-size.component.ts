import { Component } from '@angular/core';

@Component({
  selector: 'app-update-category-size',
  imports: [],
  templateUrl: './update-category-size.component.html',
  styleUrl: './update-category-size.component.css'
})
export class UpdateCategorySizeComponent {

}
