export const environment = {
  production: false,
  apiurl : "https://localhost:7172/api"
};
