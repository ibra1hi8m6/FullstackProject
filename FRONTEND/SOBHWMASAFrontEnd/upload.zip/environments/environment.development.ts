export const environment = {
  apiurl : "https://localhost:7246/api"
};
